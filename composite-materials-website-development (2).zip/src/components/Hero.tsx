import { motion } from 'framer-motion';
import { Rocket, Shield, Zap } from 'lucide-react';

const Hero = () => {
  return (
    <div className="relative h-screen flex items-center justify-center overflow-hidden bg-neutral-950">
      {/* Background with parallax effect */}
      <motion.div 
        initial={{ scale: 1.1, opacity: 0 }}
        animate={{ scale: 1, opacity: 0.6 }}
        transition={{ duration: 1.5 }}
        className="absolute inset-0 z-0"
      >
        <img 
          src="/vacuum_kit.jpg" 
          alt="Laxmi Fiber Workshop" 
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-neutral-950 via-neutral-950/40 to-transparent"></div>
      </motion.div>

      <div className="container mx-auto px-6 relative z-10 text-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="inline-flex items-center px-4 py-2 rounded-full border border-orange-500/30 bg-orange-500/10 text-orange-400 text-sm font-bold tracking-widest mb-8 backdrop-blur-md"
        >
          <Zap className="w-4 h-4 mr-2" />
          FUTURE OF COMPOSITES
        </motion.div>

        <motion.h1 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="text-5xl md:text-8xl font-black mb-8 leading-tight tracking-tighter"
        >
          LAXMI FIBER <br />
          <span className="text-orange-500 drop-shadow-[0_0_20px_rgba(249,115,22,0.4)]">COMPOSITES</span>
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="text-lg md:text-xl text-neutral-400 max-w-3xl mx-auto mb-10 leading-relaxed font-light"
        >
          Pioneering the next generation of advanced composite materials. From aerospace-grade carbon fiber to precision vacuum infusion systems.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="flex flex-col sm:flex-row items-center justify-center gap-6"
        >
          <a 
            href="#products"
            className="group relative px-10 py-4 bg-orange-600 rounded-xl overflow-hidden font-bold tracking-wide transition-all hover:pr-12"
          >
            <span className="relative z-10">EXPLORE MATERIALS</span>
            <div className="absolute inset-0 bg-white/10 translate-x-[-100%] group-hover:translate-x-0 transition-transform duration-300"></div>
          </a>
          <a 
            href="#contact"
            className="px-10 py-4 border-2 border-neutral-700 hover:border-orange-500 rounded-xl font-bold tracking-wide transition-all"
          >
            GET IN TOUCH
          </a>
        </motion.div>

        <div className="mt-20 grid grid-cols-1 sm:grid-cols-3 gap-8 max-w-4xl mx-auto">
          {[
            { icon: Rocket, title: "Aerospace Grade", value: "Premium" },
            { icon: Shield, title: "Extreme Strength", value: "Reinforced" },
            { icon: Zap, title: "Rapid Delivery", value: "On-time" }
          ].map((item, index) => (
            <motion.div
              key={item.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.8 + index * 0.1 }}
              className="flex items-center justify-center space-x-4 p-4 border border-neutral-800 rounded-2xl bg-neutral-900/50 backdrop-blur-sm"
            >
              <div className="p-3 bg-neutral-800 rounded-lg text-orange-500">
                <item.icon className="w-6 h-6" />
              </div>
              <div className="text-left">
                <p className="text-xs text-neutral-500 font-bold uppercase tracking-widest">{item.title}</p>
                <p className="text-sm font-bold text-white uppercase">{item.value}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Hero;
