import { motion } from 'framer-motion';
import { Mail, Phone, MapPin, Send } from 'lucide-react';

const Contact = () => {
  return (
    <section id="contact" className="py-24 bg-neutral-950 relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-orange-600/10 blur-[120px] rounded-full pointer-events-none opacity-50"></div>

      <div className="container mx-auto px-6 relative z-10">
        <div className="flex flex-col lg:flex-row gap-16">
          {/* Contact Details */}
          <motion.div 
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="w-full lg:w-1/2"
          >
            <span className="text-orange-500 font-bold uppercase tracking-widest text-sm">Contact Us</span>
            <h2 className="text-4xl md:text-6xl font-black mt-4 mb-8">
              Let's build the <span className="text-neutral-500">Future</span> together.
            </h2>
            <p className="text-neutral-400 text-lg mb-12">
              Get in touch with us for bulk orders, technical specifications, or custom manufacturing solutions.
            </p>

            <div className="space-y-8">
              <ContactItem 
                icon={Mail} 
                title="Email Us" 
                value="SALES.LFCOMPOSITES" 
                subValue="Contact for sales and inquiries"
              />
              <ContactItem 
                icon={Phone} 
                title="Call Us" 
                value="+91 (Request Quote)" 
                subValue="Mon-Sat, 9AM-6PM"
              />
              <ContactItem 
                icon={MapPin} 
                title="Visit Us" 
                value="Composite District" 
                subValue="Industrial Area, Laxmi Fiber Hub"
              />
            </div>
          </motion.div>

          {/* Contact Form */}
          <motion.div 
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="w-full lg:w-1/2 bg-neutral-900 border border-neutral-800 p-8 md:p-12 rounded-3xl shadow-2xl backdrop-blur-md"
          >
            <form className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-xs uppercase font-bold tracking-widest text-neutral-500 ml-1">Full Name</label>
                  <input 
                    type="text" 
                    placeholder="Enter your name" 
                    className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-4 py-3 text-white placeholder:text-neutral-700 focus:border-orange-500 outline-none transition-all"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-xs uppercase font-bold tracking-widest text-neutral-500 ml-1">Work Email</label>
                  <input 
                    type="email" 
                    placeholder="email@company.com" 
                    className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-4 py-3 text-white placeholder:text-neutral-700 focus:border-orange-500 outline-none transition-all"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-xs uppercase font-bold tracking-widest text-neutral-500 ml-1">Interested Product</label>
                <select className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-4 py-3 text-white focus:border-orange-500 outline-none transition-all">
                  <option>Carbon Fiber Tubes</option>
                  <option>Infusion Kit</option>
                  <option>Kevlar Fabric</option>
                  <option>Automotive Parts</option>
                  <option>Drone Body</option>
                  <option>Other</option>
                </select>
              </div>
              <div className="space-y-2">
                <label className="text-xs uppercase font-bold tracking-widest text-neutral-500 ml-1">Message</label>
                <textarea 
                  rows={4} 
                  placeholder="Tell us about your project requirements..." 
                  className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-4 py-3 text-white placeholder:text-neutral-700 focus:border-orange-500 outline-none transition-all resize-none"
                ></textarea>
              </div>
              <button className="w-full bg-orange-600 hover:bg-orange-700 text-white font-bold py-4 rounded-xl flex items-center justify-center space-x-2 transition-all group">
                <span>SEND MESSAGE</span>
                <Send className="w-4 h-4 group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
              </button>
            </form>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

const ContactItem = ({ icon: Icon, title, value, subValue }: { icon: any, title: string, value: string, subValue: string }) => (
  <div className="flex items-start space-x-6">
    <div className="p-4 bg-orange-600/10 text-orange-500 rounded-2xl">
      <Icon className="w-6 h-6" />
    </div>
    <div>
      <h4 className="text-sm font-bold uppercase tracking-widest text-neutral-500 mb-1">{title}</h4>
      <p className="text-xl font-bold text-white mb-1 tracking-tight">{value}</p>
      <p className="text-sm text-neutral-400">{subValue}</p>
    </div>
  </div>
);

export default Contact;
