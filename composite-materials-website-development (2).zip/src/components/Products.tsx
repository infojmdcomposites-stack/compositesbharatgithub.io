import { motion } from 'framer-motion';
import { Layers, Shield, Zap, Wind, ChevronRight } from 'lucide-react';

const products = [
  {
    name: "Carbon Fiber",
    description: "High-strength, low-weight fiber for high-performance applications.",
    icon: Layers,
    tags: ["3K", "6K", "12K", "Plain/Twill"],
    color: "bg-neutral-800"
  },
  {
    name: "Glass Fiber",
    description: "Excellent insulation and structural support for varied composites.",
    icon: Wind,
    tags: ["E-Glass", "S-Glass", "CSM"],
    color: "bg-neutral-800"
  },
  {
    name: "Kevlar Fabric",
    description: "Impact-resistant and incredibly tough aramid fibers.",
    icon: Shield,
    tags: ["High Impact", "Aramid", "Armor"],
    color: "bg-neutral-800"
  },
  {
    name: "Epoxy Resin",
    description: "Superior adhesion and structural integrity for composite layering.",
    icon: Zap,
    tags: ["Low Viscosity", "High Temp", "Clear"],
    color: "bg-neutral-800"
  },
  {
    name: "Basalt Fiber",
    description: "Sustainable alternative with high thermal and fire resistance.",
    icon: Layers,
    tags: ["Volcanic", "Eco-Friendly", "Durable"],
    color: "bg-neutral-800"
  },
  {
    name: "CF Tubes",
    description: "Precision-engineered round and square carbon fiber tubing.",
    icon: Wind,
    tags: ["High Stiff", "UAV", "Industrial"],
    color: "bg-neutral-800"
  }
];

const Products = () => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
      {products.map((product, index) => (
        <motion.div
          key={product.name}
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: index * 0.1 }}
          viewport={{ once: true }}
          className="group relative bg-neutral-900 border border-neutral-800 rounded-3xl p-8 hover:border-orange-500/50 transition-all duration-300"
        >
          <div className="flex justify-between items-start mb-6">
            <div className="p-4 bg-orange-600/10 text-orange-500 rounded-2xl group-hover:bg-orange-500 group-hover:text-white transition-all duration-300">
              <product.icon className="w-8 h-8" />
            </div>
            <div className="flex space-x-1 opacity-0 group-hover:opacity-100 transition-opacity">
              <div className="w-1.5 h-1.5 rounded-full bg-orange-500"></div>
              <div className="w-1.5 h-1.5 rounded-full bg-orange-500/50"></div>
              <div className="w-1.5 h-1.5 rounded-full bg-orange-500/20"></div>
            </div>
          </div>

          <h3 className="text-2xl font-bold mb-3 tracking-tight">{product.name}</h3>
          <p className="text-neutral-400 text-sm leading-relaxed mb-6">
            {product.description}
          </p>

          <div className="flex flex-wrap gap-2 mb-8">
            {product.tags.map((tag) => (
              <span key={tag} className="text-[10px] uppercase font-bold tracking-widest px-3 py-1 bg-neutral-800 text-neutral-500 rounded-full">
                {tag}
              </span>
            ))}
          </div>

          <button className="flex items-center text-xs font-black uppercase tracking-[0.2em] group-hover:text-orange-500 transition-colors">
            Learn More
            <ChevronRight className="w-4 h-4 ml-1 group-hover:translate-x-1 transition-transform" />
          </button>
        </motion.div>
      ))}
    </div>
  );
};

export default Products;
