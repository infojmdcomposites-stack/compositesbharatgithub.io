import { Hexagon, Globe, Share2, Mail, Phone, ChevronRight } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-neutral-950 border-t border-neutral-900 pt-24 pb-12 overflow-hidden">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-16 mb-24">
          <div className="col-span-1 lg:col-span-1">
            <div className="flex items-center space-x-2 mb-8">
              <div className="w-10 h-10 bg-orange-600 rounded-lg flex items-center justify-center">
                <Hexagon className="text-white fill-white/20" />
              </div>
              <span className="text-xl font-black tracking-tighter text-white">
                LAXMI <span className="text-orange-500">FIBER</span>
              </span>
            </div>
            <p className="text-neutral-500 text-sm leading-relaxed mb-8 pr-8">
              Innovating in composite technology for high-performance drones, automotive components, and industrial applications. 
            </p>
            <div className="flex space-x-4">
              {[Globe, Share2, Mail, Phone].map((Icon, i) => (
                <a 
                  key={i} 
                  href="#" 
                  className="w-10 h-10 rounded-full bg-neutral-900 flex items-center justify-center text-neutral-400 hover:bg-orange-600 hover:text-white transition-all transform hover:scale-110"
                >
                  <Icon size={18} />
                </a>
              ))}
            </div>
          </div>

          <div>
            <h4 className="text-white font-bold uppercase tracking-widest text-sm mb-8">Products</h4>
            <ul className="space-y-4">
              {['Carbon Fiber', 'Glass Fiber', 'Kevlar Fabric', 'Basalt Fiber', 'Epoxy Resin'].map((item) => (
                <li key={item}>
                  <a href="#products" className="text-neutral-500 hover:text-orange-500 transition-colors flex items-center group">
                    <ChevronRight size={14} className="mr-2 opacity-0 group-hover:opacity-100 transition-all -translate-x-2 group-hover:translate-x-0" />
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-white font-bold uppercase tracking-widest text-sm mb-8">Applications</h4>
            <ul className="space-y-4">
              {['Drone Body', 'Automotive Parts', 'Industrial Tubes', 'Vacuum Kits', 'Infusion Kits'].map((item) => (
                <li key={item}>
                  <a href="#applications" className="text-neutral-500 hover:text-orange-500 transition-colors flex items-center group">
                    <ChevronRight size={14} className="mr-2 opacity-0 group-hover:opacity-100 transition-all -translate-x-2 group-hover:translate-x-0" />
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-white font-bold uppercase tracking-widest text-sm mb-8">Newsletter</h4>
            <p className="text-neutral-500 text-sm mb-6">Stay updated on our latest composite technologies.</p>
            <div className="flex bg-neutral-900 rounded-xl p-1 border border-neutral-800 focus-within:border-orange-500 transition-all">
              <input 
                type="email" 
                placeholder="email@work.com" 
                className="bg-transparent text-white px-3 py-2 text-sm outline-none flex-grow"
              />
              <button className="bg-orange-600 hover:bg-orange-700 text-white px-4 py-2 rounded-lg text-sm font-bold transition-all">
                JOIN
              </button>
            </div>
          </div>
        </div>

        <div className="pt-12 border-t border-neutral-900 flex flex-col md:flex-row justify-between items-center text-neutral-600 text-xs font-medium tracking-widest uppercase">
          <p>© 2024 LAXMI FIBER COMPOSITES. ALL RIGHTS RESERVED.</p>
          <div className="flex space-x-8 mt-6 md:mt-0">
            <a href="#" className="hover:text-orange-500 transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-orange-500 transition-colors">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
