import { motion } from 'framer-motion';
import { Target, Settings, Zap } from 'lucide-react';

const Processes = () => {
  const steps = [
    {
      title: "Vacuum Infusion",
      description: "A precision molding method that uses vacuum pressure to drive resin into a laminate.",
      icon: Target,
      image: "/vacuum_kit.jpg"
    },
    {
      title: "Resin Transfer Molding",
      description: "Advanced composite fabrication techniques for consistent structural parts.",
      icon: Settings,
      image: "/automotive_parts.jpg"
    }
  ];

  return (
    <section id="processes" className="py-24 bg-neutral-900 overflow-hidden">
      <div className="container mx-auto px-6">
        <motion.div 
          initial={{ opacity: 0, x: -50 }}
          whileInView={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="max-w-3xl mb-16"
        >
          <span className="text-orange-500 font-bold uppercase tracking-widest text-sm">Our Expertise</span>
          <h2 className="text-4xl md:text-6xl font-black mt-4 mb-8">
            Precision Manufacturing <span className="text-neutral-500">Systems</span>
          </h2>
          <p className="text-neutral-400 text-lg">
            We don't just supply materials; we provide the complete process kits needed for industrial-grade manufacturing.
          </p>
        </motion.div>

        <div className="space-y-24">
          {steps.map((step, index) => (
            <motion.div 
              key={step.title}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
              className={`flex flex-col md:flex-row items-center gap-12 ${index % 2 === 1 ? 'md:flex-row-reverse' : ''}`}
            >
              <div className="w-full md:w-1/2 relative">
                <div className="absolute -inset-4 bg-orange-600/20 blur-2xl rounded-full opacity-50 group-hover:opacity-100 transition-opacity"></div>
                <div className="relative rounded-3xl overflow-hidden border border-neutral-700 shadow-2xl">
                  <img 
                    src={step.image} 
                    alt={step.title} 
                    className="w-full aspect-video object-cover transition-transform duration-700 hover:scale-105"
                  />
                </div>
              </div>
              <div className="w-full md:w-1/2">
                <div className="p-4 bg-orange-600/10 text-orange-500 rounded-2xl w-fit mb-6">
                  <step.icon className="w-8 h-8" />
                </div>
                <h3 className="text-3xl font-bold mb-6">{step.title}</h3>
                <p className="text-neutral-400 text-lg leading-relaxed mb-8">
                  {step.description}
                </p>
                <ul className="space-y-4">
                  {["Reduced Voids", "Higher Strength", "Process Control", "Eco-Friendly"].map((item) => (
                    <li key={item} className="flex items-center space-x-3 text-neutral-300">
                      <Zap className="w-5 h-5 text-orange-500" />
                      <span className="font-medium">{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Processes;
